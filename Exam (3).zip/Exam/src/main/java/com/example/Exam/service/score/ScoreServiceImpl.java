package com.example.Exam.service.score;


import com.example.Exam.entity.Score;
import com.example.Exam.repository.ScoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ScoreServiceImpl implements ScoreService{

    @Autowired
    private ScoreRepository studentScoreRepository;

    public List<Score> getAllScores() {
        return studentScoreRepository.findAll();
    }

    public Optional<Score> getScoreById(Long id) {
        return studentScoreRepository.findById(id);
    }

    public void saveScore(Score studentScore) {
        studentScoreRepository.save(studentScore);
    }

    public void deleteScore(Long id) {
        studentScoreRepository.deleteById(id);
    }
}
