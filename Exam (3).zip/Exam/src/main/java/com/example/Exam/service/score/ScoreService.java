package com.example.Exam.service.score;

import com.example.Exam.entity.Score;

import java.util.List;
import java.util.Optional;

public interface ScoreService {

    List<Score> getAllScores();
    Optional<Score> getScoreById(Long id);
    void saveScore(Score studentScore);
    void deleteScore(Long id);
}
